document.getElementById("register-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;

    if (name && email) {
        alert(`Registro exitoso. Bienvenido, ${name}!`);
        document.getElementById("register-section").style.display = "none";
        document.getElementById("food-section").style.display = "block";
    } else {
        alert("Por favor, completa todos los campos.");
    }
});

document.getElementById("food-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const foodName = document.getElementById("food").value;
    const expirationDate = document.getElementById("expiration").value;

    if (foodName && expirationDate) {
        const foodList = document.getElementById("food-list");
        const li = document.createElement("li");
        li.textContent = `${foodName} - Caduca el ${expirationDate}`;
        foodList.appendChild(li);

        document.getElementById("food").value = "";
        document.getElementById("expiration").value = "";
    } else {
        alert("Por favor, completa todos los campos.");
    }
});
